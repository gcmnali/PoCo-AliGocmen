for (let i = 0; i < 100; i++) {
    
    if(i%5 == 0){
        document.write("Power");
    }
    else if(i%7 == 0){
        document.write("Coders");
    }
    else if(i%35 == 0){
        document.write("PowerCoders"); 
    }
    else{
        document.write(i);
    }
}